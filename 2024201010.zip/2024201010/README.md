Assumptions : 
We are assuming that the files are in the same directory as the shell sripts.

Steps of Execution:

Q1: 
- Search for all the tupples having POST
- Then using '|' operator search for all the tupples having 404

Q2:
- Using awk, sum all the 4th arguments, using ',' deliminator.
